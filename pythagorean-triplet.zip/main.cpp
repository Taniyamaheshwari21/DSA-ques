//pythagorean triplet
#include <iostream>
using namespace std;
bool check(int x,int y,int z){
    int a=max(x,max(y,z));
    int b,c;
    if (a==x){
        b=y;
        c=z;
    }
    else if(a==y){
        b=x;
        c=z;
    }
    else{
        a=z;
        b=y;
        c=x;
    }
    if (a*a==b*b+c*c)
        return true;
    else
        return false;
}
int main()
{
    cout << "enter three numbers: ";
    int x, y, z;
    cin>> x>> y>> z;
    if (check(x,y,z))
        cout<<"it is a pythagorean triplet";
    else
        cout<<"not a pythagorean triplet";
    return 0;
}
