//binary to decimal  conversion
#include <iostream>
#include <cmath>
using namespace std;
int bintodeci(int bin)
{
    int deci=0;
    int rem=0;
    int x=0;
    while(bin>0)
    {
        rem=bin%10;
        deci+=(rem*pow(2,x));
        x+=1;
        bin=bin/10;
    }
    return deci;
}
int main()
{
    cout<<"enter a binary number: ";
    int bin;
    cin>>bin;
    cout<<bintodeci(bin)<<endl;
    return 0;
}