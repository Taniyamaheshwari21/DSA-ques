//longest arithmetic subarray
#include <iostream>

using namespace std;

int main()
{
    cout<<"enter number of terms: ";
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    int ans=2;
    int sub=2;
    int com_diff=0;
    int diff=a[1]-a[0];
    
    for(int i=0;i<n-1;i++){
        com_diff=a[i+1]-a[i];
        if(diff==com_diff){
            sub++;
        }
        else{
            diff=a[i+1]-a[i];
            sub=2;
        }
        ans=max(ans,sub);
    }
    cout<<ans<<" ";
    return 0;
}