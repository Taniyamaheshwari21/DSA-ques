//octal to decimal  conversion
#include <iostream>
#include <cmath>
using namespace std;
int octtodeci(int bin)
{
    int deci=0;
    int rem=0;
    int x=0;
    while(bin>0)
    {
        rem=bin%10;
        deci+=(rem*pow(8,x));
        x+=1;
        bin=bin/10;
    }
    return deci;
}
int main()
{
    cout<<"enter an octal number: ";
    int bin;
    cin>>bin;
    cout<<octtodeci(bin)<<endl;
    return 0;
}