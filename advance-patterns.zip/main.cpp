//advance patterns

#include <iostream>
using namespace std;

int main()
{
    for(int i=5;i>=1;i--){
        for (int j=1;j<=i;j++)
            cout<<j;
    
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;
    
    for(int i=1;i<=5;i++){
        for (int j=1;j<=i;j++)
            if((i+j)%2==0)
                cout<<1;
            else
                cout<<0;
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;
    
    for(int i=1;i<=5;i++){
        int k=1;
        for (int j=1;j<=5-i;j++)
            cout<<" ";
        for (int j=1;j<=i;j++){
            cout<<k<<" ";
            k+=1;
        }
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;
    
    for(int i=1;i<=5;i++){
        for (int j=1;j<=5-i;j++)
            cout<<" ";
        for (int j=i;j>=1;j--)
            cout<<j;
        for (int j=2;j<=i;j++){
            cout<<j;
        }
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;
    
    for(int i=1;i<=5;i++){
        for (int j=1;j<=5-i;j++)
            cout<<" ";
        for (int j=i;j>=1;j--)
            cout<<"*";
        for (int j=2;j<=i;j++){
            cout<<"*";
        }
        cout<<endl;
    }
    for(int i=5;i>=1;i--){
        for (int j=1;j<=5-i;j++)
            cout<<" ";
        for (int j=i;j>=1;j--)
            cout<<"*";
        for (int j=2;j<=i;j++){
            cout<<"*";
        }
        cout<<endl;
    }
    return 0;
}
