//hexa to decimal  conversion
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
int hexatodeci(string hexa)
{
    int deci=0;
    int x=1;
    int s=hexa.size();
    for(int i=s-1;i>=0;i--){
        if (hexa[i]>='0'&& hexa[i]<='9'){
            deci+=x*(hexa[i]-'0');
        }
        else if (hexa[i]>='A' && hexa[i]<='F'){
            deci+=x*(hexa[i]-'A'+10);
        }
        x*=16;
    }
    return deci;
}
int main()
{
    cout<<"enter a hexadecimal number: ";
    string hexa;
    cin>>hexa;
    cout<<hexatodeci(hexa)<<endl;
    return 0;
}